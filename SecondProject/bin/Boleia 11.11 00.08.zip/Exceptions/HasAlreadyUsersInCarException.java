package Exceptions;
	/**
	 * The exception that checks if there are already users registed in the move.
	 * @author zmurt
	 *
	 */
@SuppressWarnings("serial")
public class HasAlreadyUsersInCarException extends Exception{
	
	/**
	 * Checks if there users already in the move
	 */
	public HasAlreadyUsersInCarException() {
		super();
	}
}
