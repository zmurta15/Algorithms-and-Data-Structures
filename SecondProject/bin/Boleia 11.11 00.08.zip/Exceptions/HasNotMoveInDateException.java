package Exceptions;
	/**
	 * The exception that checks if there is a move in the date.
	 * @author zmurt
	 *
	 */
@SuppressWarnings("serial")
public class HasNotMoveInDateException extends Exception {
	
	/**
	 * Checks if there is a move in the date
	 */
	public HasNotMoveInDateException() {
		super();
	}

}
