package Exceptions;

/**
 * The exception that checks if the user has a lift in date.
 * @author zmurt
 *
 */
@SuppressWarnings("serial")
public class HasNotLiftInDateException extends Exception{
	
	/**
	 * Checks if the user has a lift with date
	 */
	public HasNotLiftInDateException() {
		super();
	}
}
