package Exceptions;

/**
 * The exception that checks if the date is valid.
 * @author zmurt
 *
 */
@SuppressWarnings("serial")
public class InvalidDateException extends Exception{
	/**
	 * Checks if the date is valid.
	 */
	public InvalidDateException() {
		super();
	}
}
