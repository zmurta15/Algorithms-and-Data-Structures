package Exceptions;

/**^
 * The exception if the user asking for lift is the same.
 * @author zmurt
 *
 */
@SuppressWarnings("serial")
public class UserIsTheSameException extends Exception {
	/**
	 * Checks if the user asking for lift is the same as the owner.
	 */
	public UserIsTheSameException() {
		super();
	}
}
