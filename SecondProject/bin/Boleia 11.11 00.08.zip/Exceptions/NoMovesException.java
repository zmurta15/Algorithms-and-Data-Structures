package Exceptions;

@SuppressWarnings("serial")
public class NoMovesException extends Exception {
	
	public NoMovesException() {
		super();
	}
}
