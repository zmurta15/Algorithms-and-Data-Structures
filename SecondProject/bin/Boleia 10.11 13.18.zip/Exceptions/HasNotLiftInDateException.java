package Exceptions;

@SuppressWarnings("serial")
public class HasNotLiftInDateException extends Exception{
	
	public HasNotLiftInDateException() {
		super();
	}
}
