package Boleia;
import User.*;
import Move.*;

import javax.activity.InvalidActivityException;

import Exceptions.*;
import dataStructures.*;


public class BoleiaClass implements Boleia {
	
	/**
	 * Number of user registed in the app.
	 */
	private int nRegists;
	
	/**
	 * User who is logged on the app.
	 */
	private User loggedUser;
	
	/**
	 * Dictionary of all the users of the app by their emails.
	 */
	private Map<String, User> emailUsers;
	
	private SortedMap<String, TwoWayList<Move>> boleias;
	
	private static final int CAPACITY = 20000;
	
	/**
	 * Creates a app.
	 */
	public BoleiaClass() {
		nRegists = 0;
		loggedUser = null;
		emailUsers = new MapWithJavaClass<String, User>(CAPACITY);
		boleias = new SortedMapWithJavaClass<String ,TwoWayList<Move> >(CAPACITY);
	}
	
	public void regista(String email, String name, String password) throws SessionModeOnException{
		if(hasLoggedUser()) {
			throw new SessionModeOnException();
		} 
		else {
			User user = new UserClass(email, name, password);
			emailUsers.insert(email, user);
			nRegists++;
		}
	}
	
	public void entrada(String email, String password) throws SessionModeOnException, UserDoesNotExistException {
		if (hasLoggedUser()) {
			throw new SessionModeOnException();
		}
		else if(!hasUserWithEmail(email)) {
			throw new UserDoesNotExistException();
		}
		else {
			loggedUser = emailUsers.find(email);
			loggedUser.incNVisits();
		}
	}
	
	public void nova(String origin, String destination, String date, String time, int duration, int seats) throws NoLoggedUserException, InvalidArgumentsException, HasMoveInDateException {
		Date d= setDate(date);
		HourMinutes t = setTime(time);
		if(!hasLoggedUser()) {
			throw new NoLoggedUserException();
		}
		else if(!validArguments(d,t, duration, seats)) {
			throw new InvalidArgumentsException();
		}
		else if(loggedUser.hasMoveInDate(date)) {
			throw new HasMoveInDateException();
		}
		else {
			Move m = new MoveClass(origin, destination, d, t, duration, seats, loggedUser);
			if(boleias.find(date) != null) {
				boleias.find(date).addLast(m);
			}
			else {
				TwoWayList<Move> moves = new DoublyLinkedList<Move>();
				moves.addLast(m);
				boleias.insert(date, moves);
			}
			loggedUser.addMove(date, m);
		}
	}
	
	public User getLoggedUser() {
		return loggedUser;
	}
	
	public void ajuda() throws NoLoggedUserException {
		if(!hasLoggedUser())
			throw new NoLoggedUserException();
	}
	
	public void termina() throws SessionModeOnException {
		if (hasLoggedUser())
			throw new SessionModeOnException();
	}
	
	public void sai() throws NoLoggedUserException {
		if(!hasLoggedUser())
			throw new NoLoggedUserException();
		loggedUser = null;
	}
	
	public int getNumberRegists() {
		return nRegists;
	}
	
	// -------------------------------------------------------------------------------------------------------------------------------------------
	
	public boolean hasUserWithEmail(String email){
		return emailUsers.find(email) != null;
	}
	
	public void setExceptionEmail (String email) throws HasAlreadyUserException {
		if(emailUsers.find(email) != null) {
			throw new HasAlreadyUserException();
		} 
	}
	
	public void setExceptionUserDoesNotExist (String email) throws UserDoesNotExistException {
		if(!hasUserWithEmail(email)) {
			throw new UserDoesNotExistException();
		}
	}
	
	public boolean hasLoggedUser() {
		return loggedUser != null;
	}
	
	public String getUserPass(String email) {
		return emailUsers.find(email).getPassword();
	}
	
	private Date setDate(String date) {
		return new DateClass(date);
	}
	
	private HourMinutes setTime(String time) {
		return new HourMinutesClass(time); 
	}
	
	private boolean validArguments(Date date, HourMinutes time, int duration, int seats) {
		return (date.isValid() && time.isValid() && duration > 0 && seats>0 && seats <=10);
	}
}
