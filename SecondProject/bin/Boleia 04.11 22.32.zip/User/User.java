package User;

import Move.Date;
import Move.Move;

public interface User {
	
	void addMove(String date, Move move);
	
	/**
	 * Gets the user's email.
	 * @return user's email.
	 */
	String getEmail();
	
	/**
	 * Gets the user's name
	 * @return user's name
	 */
	String getName();
	
	/**
	 * Gets the user's password
	 * @return user's password
	 */
	String getPassword();
	
	/**
	 * Increments the number of visits of the user
	 */
	void incNVisits();
	
	/**
	 * Gets the user's number of visits to the app
	 * @return - the user's number of visits to the app
	 */
	int getNVisits();
	
	boolean hasMoveInDate(String date);
	
	int getNMoves();
}
