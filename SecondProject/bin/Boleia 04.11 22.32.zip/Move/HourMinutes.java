package Move;

public interface HourMinutes {
	
	int getHour();
	
	int getMinutes();
	
	boolean isValid();

}
