package Move;

public interface Date extends Comparable<Date>{
	
	boolean isValid();
	
	int getYear();
	
	int getDay();
	
	int getMonth();

}
