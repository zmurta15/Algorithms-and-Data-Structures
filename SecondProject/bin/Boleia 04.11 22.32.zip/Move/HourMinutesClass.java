package Move;

public class HourMinutesClass implements HourMinutes{
	
	private static final int NUM_FIELDS = 2;
	
	private int[] raw;
	
	public HourMinutesClass(String time) {
		String[] split = time.split(":");
		raw = new int[NUM_FIELDS];
		
		for (int i = 0; i < split.length; i++) {
			raw[i] = Integer.parseInt(split[i].trim());
		}
 	}
	
	public int getHour() {
		return raw[0];
	}
	
	public int getMinutes() {
		return raw[1];
	}
	
	public boolean isValid() {
		return (getHour()>=0 && getHour()<24 && getMinutes()>=0 && getMinutes()<60);
	}

}
