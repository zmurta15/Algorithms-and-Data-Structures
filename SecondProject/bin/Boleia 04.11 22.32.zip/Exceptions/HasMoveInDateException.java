package Exceptions;

@SuppressWarnings("serial")
public class HasMoveInDateException extends Exception{
	
	public HasMoveInDateException() {
		super();
	}

}
