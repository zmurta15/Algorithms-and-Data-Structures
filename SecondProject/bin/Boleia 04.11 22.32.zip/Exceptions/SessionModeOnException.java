package Exceptions;

/**
 * The exception that checks if the app is on session mode.
 * @author zmurt
 *
 */
@SuppressWarnings("serial")
public class SessionModeOnException extends Exception{
	
	/**
	 * Checks if the app is on session mode.
	 */
	public SessionModeOnException() {
		super();
	}
	
}
