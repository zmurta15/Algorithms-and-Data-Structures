package Exceptions;

@SuppressWarnings("serial")
public class InvalidArgumentsException extends Exception {
	
	
	public InvalidArgumentsException() {
		super();
	}
}
