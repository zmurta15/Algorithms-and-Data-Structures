package Exceptions;

@SuppressWarnings("serial")
public class UserDoesNotExistException extends Exception {
	
	public UserDoesNotExistException() {
		super();
	}
}
