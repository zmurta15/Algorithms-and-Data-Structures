package dataStructures;

public class SortedMapWithJavaClass<K extends Comparable<K>, V> implements SortedMap<K , V> {

	protected java.util.SortedMap<K,V> elementos;
	protected int capPrevista;


	public SortedMapWithJavaClass(int capPrevista) {
		elementos = new java.util.TreeMap<K,V>();
		this.capPrevista = capPrevista;
	}
	
	@Override
	public boolean isEmpty() {
		return elementos.isEmpty();
	}

	@Override
	public int size() {
		return elementos.size();
	}

	@SuppressWarnings("unchecked")
	@Override
	public Iterator<K> keys() throws NoElementException {
		return (Iterator<K>) elementos.keySet().iterator();
	}

	@SuppressWarnings("unchecked")
	@Override
	public Iterator<V> values() throws NoElementException {
		return (Iterator<V>) elementos.values().iterator();
	}

	@SuppressWarnings("unchecked")
	@Override
	public Iterator<Entry<K, V>> iterator() throws NoElementException {
		return (Iterator<Entry<K, V>>) elementos.entrySet().iterator();
	}

	@Override
	public V find(K key) {
		return elementos.get(key);
	}

	@Override
	public V insert(K key, V value) {
		return elementos.put(key, value);
	}

	@Override
	public V remove(K key) {
		return elementos.remove(key);
	}

	@Override
	public Entry<K, V> minEntry() throws NoElementException {
		if(isEmpty()) {
			throw new NoElementException();
		}
		Iterator<Entry<K,V>> it = this.iterator();
		return it.next();
		
	}

	@Override
	public Entry<K, V> maxEntry() throws NoElementException {
		if(isEmpty() ) {
			throw new NoElementException();
		}
		Iterator<Entry<K,V>> it = this.iterator();
		Entry<K,V> aux = null;
		while(it.hasNext()) {
			aux = it.next();
		}
		return aux;
	}

}


