package Exceptions;

/**
 * The exception that checks if the user exists.
 * @author zmurt
 *
 */
@SuppressWarnings("serial")
public class UserDoesNotExistException extends Exception {
	/**
	 * Checks if the user exists.
	 */
	public UserDoesNotExistException() {
		super();
	}
}
