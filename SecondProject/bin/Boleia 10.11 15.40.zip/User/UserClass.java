package User;
import Move.*;
import dataStructures.*;

/**
 * 
 * @author zmurt
 *
 */
public class UserClass implements User{
	
	
	/**
	 * User's email
	 */
	private String email;
	
	/**
	 * User's name
	 */
	private String name;
	
	/**
	 * User's password
	 */
	private String password;
	
	/**
	 * Number of visits of the user in the app
	 */
	private int nVisits;
	
	/**
	 * Number of moves registed in the app
	 */
	private int nMoves;
	
	/**
	 * Moves of the user registed in the date
	 */
	private SortedMap<Date, Move> moves;
	
	/**
	 * Lifts of the user registed in the date
	 */
	private SortedMap<Date, Move> lifts;
	
	/**
	 * Collection of the dates of the moves in string that gives object date
	 */
	private Map<String, Date> datesMoves;
	
	/**
	 * Collection of the dates of the lifts in string that gives object date
	 */
	private Map<String, Date> datesLifts;
	
	/**
	 * Creates a new user.
	 * @param email - email of the new user
	 * @param name - name of the new user
	 * @param password - password of the new user
	 */
	public UserClass(String email, String name, String password) {
		this.email = email;
		this.name = name;
		this.password = password;
		this.nVisits = 0;
		this.nMoves = 0;
		this.moves = new SortedMapWithJavaClass<Date, Move>();
		this.lifts = new SortedMapWithJavaClass<Date, Move>();
		this.datesMoves = new MapWithJavaClass<String, Date>();
		this.datesLifts = new MapWithJavaClass<String, Date>();
	}
	
	public void addMove(Date date, Move move, String date1) {
		datesMoves.insert(date1, date);
		moves.insert(date, move);
		nMoves++;
	}
	
	public void addLift(Date date, Move lift) {
		datesLifts.insert(date.getDate(), date);
		lifts.insert(date, lift);
	}
	
	
	public String getEmail() {
		return email;
	}
	
	public String getName() {
		return name;
	}
	
	public String getPassword() {
		return password;
	}
	
	public void incNVisits() {
		nVisits++;
	}
	
	public int getNVisits() {
		return nVisits;
	}
	
	public boolean hasMoveOrLiftInDate(String date) {
		return ((datesMoves.find(date) != null) || (datesLifts.find(date) != null));
	}
	
	public int getNMoves() {
		return nMoves;
	}
	
	public boolean hasMoveInDate(String date) {
		return datesMoves.find(date) != null;
	}
	
	public boolean hasLiftInDate (String date) {
		return datesLifts.find(date) != null;
	}
	
	public boolean hasAlreadyUserInCar(String date) {
		Date d = datesMoves.find(date);
		Move move = moves.find(d);
		return move.hasUsersInCar();
	}
	
	public void removeMove(String date) {
		Date d = datesMoves.find(date);
		moves.remove(d);
		nMoves--;
		datesMoves.remove(date);
	}
	
	public void removeLift(String date) {
		Date d = datesLifts.find(date);
		Move m = lifts.find(d);
		lifts.remove(d);
		m.removeUser(this);
		
	}
	
	public Move getMoveWithDate(String date) {
		return moves.find(datesMoves.find(date));
	}
	
	public Iterator<Entry<Date, Move>> iteratorMoves() {
		Iterator<Entry<Date, Move>> it = moves.iterator();
		return it;
	}
	
	public Iterator<Entry<Date, Move>> iteratorLifts() {
		Iterator<Entry<Date, Move>> it = lifts.iterator();
		return it;
	}

}
