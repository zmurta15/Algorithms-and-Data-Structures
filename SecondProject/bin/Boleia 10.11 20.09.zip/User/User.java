package User;

import Move.*;
import dataStructures.Entry;
import dataStructures.Iterator;

public interface User {
	
	void addMove(Date date, Move move, String date1);
	
	void addLift(Date date, Move lift);
	
	/**
	 * Gets the user's email.
	 * @return user's email.
	 */
	String getEmail();
	
	/**
	 * Gets the user's name
	 * @return user's name
	 */
	String getName();
	
	/**
	 * Gets the user's password
	 * @return user's password
	 */
	String getPassword();
	
	/**
	 * Increments the number of visits of the user
	 */
	void incNVisits();
	
	/**
	 * Gets the user's number of visits to the app
	 * @return - the user's number of visits to the app
	 */
	int getNVisits();
	
	/**
	 * Checks if there the user has already a move in the date
	 * @param date - the date passed as a string
	 * @return true, if the user has a move in the date; false, otherwise
	 */
	boolean hasMoveOrLiftInDate(Date date);
	
	/**
	 * Gets the number of the moves of the user
	 * @return the number of moves of the user
	 */
	int getNMoves();
	
	/**
	 * Checks if the user has a move in date
	 * @param date - date of the move
	 * @return true, if the user as move in date, false otherwise
	 */
	boolean hasMoveInDate(Date date);
	/**
	 * Checks if the user has lift with date
	 * @param date - date of the lift
	 * @return true, if has a lift with date, false, otherwise
	 */
	boolean hasLiftInDate (Date date);
	
	/**
	 * Remove lift from the user
	 * @param date - date of the lift
	 */
	void removeLift(Date date);
	
	/**
	 * Check if there are people in the move with date of the user
	 * @param date - date of the move
	 * @return true, if has already users, false otherwise
	 */
	boolean hasAlreadyUserInCar(Date date);
	
	/**
	 * Removes a move of the user.
	 * @param date - date of the move
	 */
	void removeMove(Date date);
	/**
	 * Gets the move with date
	 * @param date - date of the moves
	 * @return the move with date date
	 */
	Move getMoveWithDate(Date date);
	
	Iterator<Entry<Date, Move>> iteratorMoves();
	
	Iterator<Entry<Date, Move>> iteratorLifts();
}
