package User;

import Move.*;

public interface User {
	
	void addMove(Date date, Move move, String date1);
	
	void addLift(Date date, Move lift);
	
	/**
	 * Gets the user's email.
	 * @return user's email.
	 */
	String getEmail();
	
	/**
	 * Gets the user's name
	 * @return user's name
	 */
	String getName();
	
	/**
	 * Gets the user's password
	 * @return user's password
	 */
	String getPassword();
	
	/**
	 * Increments the number of visits of the user
	 */
	void incNVisits();
	
	/**
	 * Gets the user's number of visits to the app
	 * @return - the user's number of visits to the app
	 */
	int getNVisits();
	
	/**
	 * Checks if there the user has already a move in the date
	 * @param date - the date passed as a string
	 * @return true, if the user has a move in the date; false, otherwise
	 */
	boolean hasMoveOrLiftInDate(String date);
	
	/**
	 * Gets the number of the moves of the user
	 * @return the number of moves of the user
	 */
	int getNMoves();
	
	boolean HasMoveInDate(String date);
	
	boolean hasAlreadyUserInCar(String date);
	
	void removeMove(String date);
	
	Move getMoveWithDate(String date);
}
