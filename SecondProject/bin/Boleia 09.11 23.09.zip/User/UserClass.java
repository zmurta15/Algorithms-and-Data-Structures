package User;
import Move.*;
import dataStructures.*;

/**
 * 
 * @author zmurt
 *
 */
public class UserClass implements User{
	
	private static final int CAPACITY = 20000;
	
	/**
	 * User's email
	 */
	private String email;
	
	/**
	 * User's name
	 */
	private String name;
	
	/**
	 * User's password
	 */
	private String password;
	
	/**
	 * Number of visits of the user in the app
	 */
	private int nVisits;
	
	/**
	 * Number of moves registed in the app
	 */
	private int nMoves;
	
	//mudamos de two way list para Sortemap em que a chave e a propria date e o value e deslocacao associada a essa date
	private SortedMap<Date, Move> moves;
	
	private SortedMap<Date, Move> lifts;
	
	private Map<String, Date> datesMoves;
	
	private Map<String, Date> datesLifts;
	
	/**
	 * Creates a new user.
	 * @param email - email of the new user
	 * @param name - name of the new user
	 * @param password - password of the new user
	 */
	public UserClass(String email, String name, String password) {
		this.email = email;
		this.name = name;
		this.password = password;
		this.nVisits = 0;
		this.nMoves = 0;
		this.moves = new SortedMapWithJavaClass<Date, Move>();
		this.lifts = new SortedMapWithJavaClass<Date, Move>();
		this.datesMoves = new MapWithJavaClass<String, Date>();
		this.datesLifts = new MapWithJavaClass<String, Date>();
	}
	
	public void addMove(Date date, Move move, String date1) {
		datesMoves.insert(date1, date);
		moves.insert(date, move);
		nMoves++;
	}
	
	public void addLift(Date date, Move lift) {
		datesLifts.insert(date.getDate(), date);
		lifts.insert(date, lift);
	}
	
	
	public String getEmail() {
		return email;
	}
	
	public String getName() {
		return name;
	}
	
	public String getPassword() {
		return password;
	}
	
	public void incNVisits() {
		nVisits++;
	}
	
	public int getNVisits() {
		return nVisits;
	}
	
	public boolean hasMoveOrLiftInDate(String date) {
		return ((datesMoves.find(date) != null) || (datesLifts.find(date) != null));
	}
	
	public int getNMoves() {
		return nMoves;
	}
	
	public boolean HasMoveInDate(String date) {
		return datesMoves.find(date) != null;
	}
	
	public boolean hasAlreadyUserInCar(String date) {
		Date d = datesMoves.find(date);
		Move move = moves.find(d);
		return move.hasUsersInCar();
	}
	
	public void removeMove(String date) {
		Date d = datesMoves.find(date);
		moves.remove(d);
		nMoves--;
		datesMoves.remove(date);
	}
	
	public Move getMoveWithDate(String date) {
		return moves.find(datesMoves.find(date));
	}

}
