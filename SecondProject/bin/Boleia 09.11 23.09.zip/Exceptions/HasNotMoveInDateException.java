package Exceptions;

@SuppressWarnings("serial")
public class HasNotMoveInDateException extends Exception {
	
	public HasNotMoveInDateException() {
		super();
	}

}
