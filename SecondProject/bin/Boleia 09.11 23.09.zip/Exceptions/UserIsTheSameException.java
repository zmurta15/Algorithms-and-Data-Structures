package Exceptions;

@SuppressWarnings("serial")
public class UserIsTheSameException extends Exception {
	
	public UserIsTheSameException() {
		super();
	}
}
