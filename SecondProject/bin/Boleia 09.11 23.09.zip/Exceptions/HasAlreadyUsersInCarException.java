package Exceptions;

@SuppressWarnings("serial")
public class HasAlreadyUsersInCarException extends Exception{
	
	public HasAlreadyUsersInCarException() {
		super();
	}
}
