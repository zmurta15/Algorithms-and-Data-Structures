package Exceptions;

@SuppressWarnings("serial")
/**
 * The exception that cheks if a user has already a move in a specific date
 * @author Jose Murta && Diogo Rodrigues
 *
 */
public class HasMoveInDateException extends Exception{
	
	/**
	 * Checks if the user has a move in the date
	 */
	public HasMoveInDateException() {
		super();
	}

}
