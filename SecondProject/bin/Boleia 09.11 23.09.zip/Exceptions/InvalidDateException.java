package Exceptions;

@SuppressWarnings("serial")
public class InvalidDateException extends Exception{
	
	public InvalidDateException() {
		super();
	}
}
