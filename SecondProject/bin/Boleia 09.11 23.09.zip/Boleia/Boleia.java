package Boleia;

import Exceptions.*;
import User.*;

public interface Boleia {
	
	/**
	 * Checks if there is a user logged in the app.
	 * @return true, if the user is logged: false, otherwise.
	 */
	boolean hasLoggedUser();
	
	/**
	 * Shows to user all the commands.
	 * @throws NoLoggedUserException - if the user is not logged
	 */
	void ajuda() throws NoLoggedUserException;
	
	/**
	 * Ends the app.
	 * @throws SessionModeOnException - if there is a user logged
	 */
	void termina() throws SessionModeOnException;
	
	/**
	 * Ends the session of the logged user.
	 * @throws NoLoggedUserException - if there isn't a logged user.
	 */
	String sai() throws NoLoggedUserException;
	
	/**
	 * Gets the logged user.
	 * @return the logged user.
	 */
	User getLoggedUser();
	
	/**
	 * Regists a new user in the app.
	 * @param email - email of the new user
	 * @param name - name of the new user
	 * @param password - password of the new user
	 * @throws SessionModeOnException - if there isn't a logged user.
	 */
	void regista(String email, String name, String password) throws SessionModeOnException;
	
	/**
	 * Logins a user to the appS
	 * @param email - email of the user
	 * @param password - password of the user
	 * @throws SessionModeOnException - if there is already a logged user
	 * @throws UserDoesNotExistException - if the email of the user does not exist
	 */
	void entrada(String email, String password) throws SessionModeOnException, UserDoesNotExistException;
	
	/**
	 * Regists a new move to the app's logged useer
	 * @param origin - the move's origin
	 * @param destination - the move's destination
	 * @param date - the move's date
	 * @param time - the move's time
	 * @param duration - the move's duration
	 * @param seats - the move's available seats
	 * @throws NoLoggedUserException - if there is no logged user in the app
	 * @throws InvalidArgumentsException - if the arguments(date, time, duration, seats) are invalid
	 * @throws HasMoveInDateException - if the logged user has already a move (either a move or a lift) in the date 
	 */
	void nova(String origin, String destination, String date, String time, int duration, int seats) throws NoLoggedUserException, InvalidArgumentsException, HasMoveInDateException;
	
	
	void remove(String date) throws NoLoggedUserException, InvalidDateException, HasNotMoveInDateException, HasAlreadyUsersInCarException;
	
	void boleia(String email, String date) throws NoLoggedUserException, UserDoesNotExistException, InvalidDateException, HasNotMoveInDateException, UserIsTheSameException, HasMoveInDateException;
	
	
	/**
	 * Gets the number of users registed in the app.
	 * @return the number of regists in the app.
	 */
	int getNumberRegists();
	
	/**
	 * Checks if there is a user with the email.
	 * @param email - user's email
	 * @return true, if the user exists; false, otherwise
	 */
	boolean hasUserWithEmail(String email);
	
	/**
	 * Checks if there a user with the email.
	 * @param email - user's name
	 * @throws HasAlreadyUserException - if there is a user.
	 */
	void setExceptionEmail (String email) throws HasAlreadyUserException;
	
	/**
	 * Checks if there is no user with the email 
	 * @param email - the user's email
	 * @throws UserDoesNotExistException - if there is no user with the given email
	 */
	void setExceptionUserDoesNotExist (String email) throws UserDoesNotExistException;
	
	void setExceptionSessionModeOn() throws SessionModeOnException;
	
	/**
	 * Gets the user password
	 * @param email - the user's email
	 * @return the password of the user with the given email
	 */
	String getUserPass(String email);
	
	int getWaiting(String email, String date);
	
}
