package Exceptions;

/**
 * The exception that checks if there isn't a logged user
 * @author zmurt
 *
 */
@SuppressWarnings("serial")
public class NoLoggedUserException extends Exception {
	/**
	 * Checks if there isn't a loged user.
	 */
	public NoLoggedUserException() {
		super();
	}
}
