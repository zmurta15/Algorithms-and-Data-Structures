package Exceptions;

@SuppressWarnings("serial")
/**
 * The exception that checks if the arguments are valid. (date, time, etc...)
 * @author zmurt
 *
 */
public class InvalidArgumentsException extends Exception {
	
	/**
	 * Checks if the arguments given are valid.
	 */
	public InvalidArgumentsException() {
		super();
	}
}
