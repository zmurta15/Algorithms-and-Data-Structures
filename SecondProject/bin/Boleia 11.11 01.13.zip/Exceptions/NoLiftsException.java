package Exceptions;

@SuppressWarnings("serial")
public class NoLiftsException extends Exception {
	
	public NoLiftsException() {
		super();
	}

}
