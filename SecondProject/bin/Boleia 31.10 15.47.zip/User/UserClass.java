package User;

public class UserClass implements User{
	
	/**
	 * User's email
	 */
	private String email;
	
	/**
	 * User's name
	 */
	private String name;
	
	/**
	 * User's password
	 */
	private String password;
	
	/**
	 * Number of visits of the user in the app
	 */
	private int nVisits;
	
	/**
	 * Number of moves registed in the app
	 */
	private int nMoves;
	
	//FALTA AS DUAS TWOWAYLIST
	
	/**
	 * Creates a new user.
	 * @param email - email of the new user
	 * @param name - name of the new user
	 * @param password - password of the new user
	 */
	public UserClass(String email, String name, String password) {
		this.email = email;
		this.name = name;
		this.password = password;
		this.nVisits = 0;
		this.nMoves = 0;
	}
	
	public String getEmail() {
		return email;
	}
	
	public String getName() {
		return name;
	}
}
