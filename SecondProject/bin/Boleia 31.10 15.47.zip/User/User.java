package User;

public interface User {
	
	/**
	 * Gets the user's email.
	 * @return user's email.
	 */
	String getEmail();
	
	/**
	 * Gets the user's name
	 * @return user's name
	 */
	String getName();
}
