package Exceptions;

/**
 * The exception that checks if there is already a user with the email in the app.
 * @author zmurt
 *
 */
@SuppressWarnings("serial")
public class HasAlreadyUserException extends Exception {
	/**
	 * Check if the user already exists.
	 */
	public HasAlreadyUserException() {
		super();
	}

}
