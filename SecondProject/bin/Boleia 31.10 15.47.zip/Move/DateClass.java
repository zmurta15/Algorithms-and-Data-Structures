package Move;

public class DateClass implements Date {

}
