package Move;

public class MoveClass implements Move {

}
