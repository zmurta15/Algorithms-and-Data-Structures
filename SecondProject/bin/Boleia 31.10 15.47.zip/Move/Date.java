package Move;

public interface Date {

}
