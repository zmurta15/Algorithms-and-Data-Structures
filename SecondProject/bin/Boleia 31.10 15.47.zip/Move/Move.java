package Move;

public interface Move {

}
