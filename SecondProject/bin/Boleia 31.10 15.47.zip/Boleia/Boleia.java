package Boleia;

import Exceptions.*;
import User.*;

public interface Boleia {
	
	/**
	 * Checks if there is a user logged in the app.
	 * @return true, if the user is logged: false, otherwise.
	 */
	boolean hasLoggedUser();
	
	/**
	 * Shows to user all the commands.
	 * @throws NoLoggedUserException - if the user is not logged
	 */
	void ajuda() throws NoLoggedUserException;
	
	/**
	 * Ends the app.
	 * @throws SessionModeOnException - if there is a user logged
	 */
	void termina() throws SessionModeOnException;
	
	/**
	 * Ends the session of the logged user.
	 * @throws NoLoggedUserException - if there isn't a logged user.
	 */
	void sai() throws NoLoggedUserException;
	
	/**
	 * Gets the logged user.
	 * @return the logged user.
	 */
	User getLoggedUser();
	
	/**
	 * Regists a new user in the app.
	 * @param email - email of the new user
	 * @param name - name of the new user
	 * @param password - password of the new user
	 * @throws SessionModeOnException - if there isn't a logged user.
	 */
	void regista(String email, String name, String password) throws SessionModeOnException;
	
	/**
	 * Gets the number of users registed in the app.
	 * @return the number of regists in the app.
	 */
	int getNumberRegists();
	
	/**
	 * Checks if there is a user with the email.
	 * @param email - user's email
	 * @return true, if the user exists; false, otherwise
	 */
	boolean hasUserWithEmail(String email);
	
	/**
	 * Checks if there a user with the email.
	 * @param email - user's name
	 * @throws HasAlreadyUserException - if there is a user.
	 */
	void setExceptionEmail (String email) throws HasAlreadyUserException;
}
