package User;
import Move.*;
import dataStructures.*;

/**
 * 
 * @author zmurt
 *
 */
public class UserClass implements User{
	
	private static final int CAPACITY = 20000;
	
	/**
	 * User's email
	 */
	private String email;
	
	/**
	 * User's name
	 */
	private String name;
	
	/**
	 * User's password
	 */
	private String password;
	
	/**
	 * Number of visits of the user in the app
	 */
	private int nVisits;
	
	/**
	 * Number of moves registed in the app
	 */
	private int nMoves;
	
	//mudamos de two way list para Sortemap em que a chave e a propria date e o value e deslocacao associada a essa date
	private SortedMap<String, Move> moves;
	
	private SortedMap<String, Move> lifts;
	
	//private List<String> allDates;
	
	/**
	 * Creates a new user.
	 * @param email - email of the new user
	 * @param name - name of the new user
	 * @param password - password of the new user
	 */
	public UserClass(String email, String name, String password) {
		this.email = email;
		this.name = name;
		this.password = password;
		this.nVisits = 0;
		this.nMoves = 0;
		this.moves = new SortedMapWithJavaClass<String, Move>(CAPACITY);
		this.lifts = new SortedMapWithJavaClass<String, Move>(CAPACITY);
		//this.allDates = new DoublyLinkedList<String>();
	}
	
	public void addMove(String date, Move move) {
		moves.insert(date, move);
		nMoves++;
		//allDates.addLast(date.getDate());
	}
	
	
	
	public String getEmail() {
		return email;
	}
	
	public String getName() {
		return name;
	}
	
	public String getPassword() {
		return password;
	}
	
	public void incNVisits() {
		nVisits++;
	}
	
	public int getNVisits() {
		return nVisits;
	}
	
	public boolean hasMoveInDate(String date) {
		return ((moves.find(date) != null) || (lifts.find(date) != null));
	}
	
	public int getNMoves() {
		return nMoves;
	}


}
