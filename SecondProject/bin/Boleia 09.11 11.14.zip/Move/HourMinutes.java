package Move;

public interface HourMinutes {
	
	/**
	 * Gets the hour at the time
	 * @return the hour
	 */
	int getHour();
	
	/**
	 * Gets the minutes at the time
	 * @return the minutes
	 */
	int getMinutes();
	
	/**
	 * Checks if a time with hour and minutes is valid
	 * @return true, if the hour is valid; false, otherwise
	 */
	boolean isValid();

}
