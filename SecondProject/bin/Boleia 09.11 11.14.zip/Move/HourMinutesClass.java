package Move;

public class HourMinutesClass implements HourMinutes{
	
	private static final int NUM_FIELDS = 2;
	
	/**
	 * Array of the integers of the date
	 */
	private int[] raw;
	
	/**
	 * Builds a new raw time object.
	 * 
	 * @param time - a string of the form N1:N2, where N1 and N2 are positive
	 *             numbers representable as integers.
	 */
	public HourMinutesClass(String time) {
		String[] split = time.split(":");
		raw = new int[NUM_FIELDS];
		
		for (int i = 0; i < split.length; i++) {
			raw[i] = Integer.parseInt(split[i].trim());
		}
 	}
	
	public int getHour() {
		return raw[0];
	}
	
	public int getMinutes() {
		return raw[1];
	}
	
	public boolean isValid() {
		return (getHour()>=0 && getHour()<24 && getMinutes()>=0 && getMinutes()<60);
	}

}
