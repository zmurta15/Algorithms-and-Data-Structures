package Exceptions;

@SuppressWarnings("serial")
/**
 * 
 * @author zmurt
 *
 */
public class InvalidArgumentsException extends Exception {
	
	
	public InvalidArgumentsException() {
		super();
	}
}
